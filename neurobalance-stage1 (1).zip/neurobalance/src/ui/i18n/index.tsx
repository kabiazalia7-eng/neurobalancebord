import { createContext, useContext, useState, type ReactNode } from 'react';
import { APP, LANGS, type Lang } from '../../config/app';
import { kk, type Dict } from './kk';
import { ru } from './ru';
import { en } from './en';

const dicts: Record<Lang, Dict> = { kk, ru, en };
type Key = keyof Dict;
interface Ctx { lang: Lang; setLang: (l: Lang) => void; t: (k: Key, vars?: Record<string, string>) => string }
const I18n = createContext<Ctx>(null!);

function initialLang(): Lang {
  const saved = localStorage.getItem(APP.langStorageKey) as Lang | null;
  return saved && LANGS.includes(saved) ? saved : APP.defaultLang;
}

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(initialLang);
  const setLang = (l: Lang) => { localStorage.setItem(APP.langStorageKey, l); setLangState(l); };
  const t: Ctx['t'] = (k, vars) =>
    Object.entries(vars ?? {}).reduce((s, [a, b]) => s.replace(`{${a}}`, b), dicts[lang][k]);
  return <I18n.Provider value={{ lang, setLang, t }}>{children}</I18n.Provider>;
}
export const useI18n = () => useContext(I18n);
