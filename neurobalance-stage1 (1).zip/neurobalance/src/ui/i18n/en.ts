import type { Dict } from './kk';
export const en: Dict = {
  hello: 'Hello, {name}!', guest: 'friend',
  nav_home: 'Home', nav_games: 'Games', nav_results: 'Results', nav_profile: 'Profile', nav_journal: 'Journal', nav_settings: 'Settings',
  device: 'Device', device_off: 'Not connected', battery: 'Battery', na: 'n/a',
  card_adhd: 'ADHD games', card_cp: 'CP games',
  bs: 'Overall balance score', sway: 'Sway amplitude', react: 'Reaction time', hold: 'Stable hold time',
  exits: 'Stability boundary exits', asym: 'Left/right difference',
  last_results: 'Recent results', start_game: 'Start game', finish: 'Finish', pause: 'Pause', hint_zone: 'Keep it in the target zone!',
  tab_all: 'All', tab_adhd: 'ADHD', tab_cp: 'CP',
  stub: 'This section will be built in later stages.',
  setup_title: 'Connect device', setup_bt: 'Bluetooth on', setup_found: 'Device found', setup_linked: 'Connection established', setup_ready: 'Ready!',
  calibrate: 'Calibrate zero', demo_mode: 'Demo mode', language: 'Language', ai_module: 'AI module (off)',
  prototype_note: 'Research prototype. Not a medical device. No claims of treatment, diagnosis or clinical efficacy.',
  ios_note: 'Web Bluetooth is unavailable on iOS. Use demo mode.'
};
