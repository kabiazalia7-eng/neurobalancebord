// NOTE: Kazakh strings should be reviewed by a native speaker.
export const kk = {
  hello: 'Сәлем, {name}!',
  guest: 'дос',
  nav_home: 'Басты бет', nav_games: 'Ойындар', nav_results: 'Нәтижелер', nav_profile: 'Профиль', nav_journal: 'Журнал', nav_settings: 'Баптаулар',
  device: 'Құрылғы', device_off: 'Қосылмаған', battery: 'Батарея', na: 'н/д',
  card_adhd: 'СДВГ – ойындар', card_cp: 'ДЦП – ойындар',
  bs: 'Жалпы тепе-теңдік көрсеткіші', sway: 'Тербеліс амплитудасы', react: 'Реакция уақыты', hold: 'Тұрақты ұстау уақыты',
  exits: 'Шекарадан шығу саны', asym: 'Сол және оң жақ айырмашылығы',
  last_results: 'Соңғы нәтижелер', start_game: 'Ойынды бастау', finish: 'Аяқтау', pause: 'Үзіліс', hint_zone: 'Мақсатты аймақта ұста!',
  tab_all: 'Жалпы', tab_adhd: 'СДВГ', tab_cp: 'ДЦП',
  stub: 'Бұл бөлім келесі кезеңдерде жасалады.',
  setup_title: 'Құрылғыны қосу', setup_bt: 'Bluetooth қосылды', setup_found: 'Құрылғы табылды', setup_linked: 'Байланыс орнатылды', setup_ready: 'Дайын!',
  calibrate: 'Нөлді калибрлеу', demo_mode: 'Демо-режим', language: 'Тіл', ai_module: 'ИИ-модуль (өшірулі)',
  prototype_note: 'Зерттеу прототипі. Медициналық құрал емес. Емдеу, диагностика немесе клиникалық тиімділік туралы мәлімдеме жоқ.',
  ios_note: 'iOS құрылғыларында Web Bluetooth жұмыс істемейді. Демо-режимді қолданыңыз.'
};
export type Dict = typeof kk;
