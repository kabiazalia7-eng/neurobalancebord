import { useI18n } from '../i18n';
import { Penguin } from './Penguin';
export type Route = 'home' | 'games' | 'results' | 'profile' | 'journal' | 'settings';
export const ROUTES: Route[] = ['home', 'games', 'results', 'profile', 'journal', 'settings'];

export function Sidebar({ route, go }: { route: Route; go: (r: Route) => void }) {
  const { t } = useI18n();
  return (
    <nav className="flex w-60 shrink-0 flex-col gap-2 bg-navy p-4 text-white" aria-label="main">
      <div className="mb-4 flex items-center gap-2"><Penguin size={48} /><span className="text-xl font-extrabold">BalanceBoard</span></div>
      {ROUTES.map((r) => (
        <button key={r} onClick={() => go(r)} aria-current={route === r ? 'page' : undefined}
          className={`min-h-12 rounded-2xl px-4 text-left text-lg font-semibold focus-visible:outline focus-visible:outline-4 focus-visible:outline-mint ${route === r ? 'bg-navy2 text-mint' : 'text-white/80 hover:bg-navy2'}`}>
          {t(`nav_${r}` as const)}
        </button>
      ))}
    </nav>
  );
}
