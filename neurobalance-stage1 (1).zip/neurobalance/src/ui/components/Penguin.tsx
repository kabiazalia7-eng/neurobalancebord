/** Procedural mascot; can later be swapped for an illustration without touching logic. */
export function Penguin({ size = 96 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" role="img" aria-label="penguin">
      <ellipse cx="32" cy="37" rx="17" ry="20" fill="#12224a" />
      <ellipse cx="32" cy="41" rx="11" ry="14" fill="#fff" />
      <circle cx="27" cy="28" r="3" fill="#fff" /><circle cx="37" cy="28" r="3" fill="#fff" />
      <circle cx="27" cy="28" r="1.4" fill="#12224a" /><circle cx="37" cy="28" r="1.4" fill="#12224a" />
      <path d="M28.5 33h7l-3.5 4.5z" fill="#4fd8b8" />
    </svg>
  );
}
