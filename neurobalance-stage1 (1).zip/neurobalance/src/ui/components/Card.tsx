import type { ReactNode } from 'react';
export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-card bg-white p-6 shadow-[0_8px_30px_rgba(18,34,74,0.08)] ${className}`}>{children}</section>;
}
export function BigButton({ children, onClick, tone = 'main' }: { children: ReactNode; onClick?: () => void; tone?: 'main' | 'soft' }) {
  const cls = tone === 'main' ? 'bg-grad-main text-white' : 'bg-sky text-navy';
  return <button onClick={onClick} className={`min-h-14 rounded-pill px-8 text-lg font-bold focus-visible:outline focus-visible:outline-4 focus-visible:outline-brand ${cls}`}>{children}</button>;
}
