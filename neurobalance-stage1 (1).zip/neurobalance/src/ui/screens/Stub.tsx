import { Card } from '../components/Card';
import { useI18n } from '../i18n';
import { LANGS } from '../../config/app';
type K = 'nav_games' | 'nav_results' | 'nav_profile' | 'nav_journal';

export function Stub({ title }: { title: K }) {
  const { t } = useI18n();
  return <Card><h1 className="text-3xl font-extrabold">{t(title)}</h1><p className="mt-3 text-lg">{t('stub')}</p></Card>;
}

export function Settings() {
  const { t, lang, setLang } = useI18n();
  return (
    <div className="flex flex-col gap-6">
      <Card><h1 className="text-3xl font-extrabold">{t('nav_settings')}</h1>
        <div className="mt-4 flex items-center gap-3"><span className="text-lg font-semibold">{t('language')}:</span>
          {LANGS.map((l) => (<button key={l} onClick={() => setLang(l)} aria-pressed={l === lang}
            className={`min-h-12 min-w-16 rounded-pill px-4 font-bold ${l === lang ? 'bg-grad-main text-white' : 'bg-sky text-navy'}`}>{l.toUpperCase()}</button>))}
        </div>
        <p className="mt-4 rounded-2xl bg-sky p-4 font-semibold text-navy">{t('prototype_note')}</p>
        <p className="mt-3 text-ink/70">{t('ios_note')}</p>
      </Card>
    </div>
  );
}
