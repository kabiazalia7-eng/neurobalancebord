import { Card, BigButton } from '../components/Card';
import { Penguin } from '../components/Penguin';
import { useI18n } from '../i18n';

/** Layout only: all values are placeholders until the score layer exists (stage 3). */
export function Home({ go }: { go: (r: 'games') => void }) {
  const { t } = useI18n();
  const four = ['sway', 'hold', 'exits', 'asym'] as const;
  return (
    <div className="flex flex-col gap-6">
      <Card className="flex items-center gap-6 bg-grad-main text-white">
        <Penguin size={110} />
        <div><h1 className="text-3xl font-extrabold">{t('hello', { name: t('guest') })}</h1>
          <p className="mt-1 text-lg">{t('device')}: {t('device_off')} · {t('battery')}: {t('na')}</p></div>
      </Card>
      <div className="grid gap-6 md:grid-cols-2">
        {(['card_adhd', 'card_cp'] as const).map((k) => (
          <Card key={k} className="flex items-center justify-between"><h2 className="text-2xl font-bold">{t(k)}</h2><BigButton onClick={() => go('games')}>{t('start_game')}</BigButton></Card>
        ))}
      </div>
      <Card>
        <h2 className="text-xl font-bold">{t('bs')}</h2>
        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          {four.map((k) => (<div key={k} className="rounded-2xl bg-sky p-4"><div className="text-sm font-semibold text-navy2">{t(k)}</div><div className="text-3xl font-extrabold text-navy">{t('na')}</div></div>))}
        </div>
      </Card>
      <Card><h2 className="text-xl font-bold">{t('last_results')}</h2><p className="mt-2 text-ink/70">{t('stub')}</p></Card>
    </div>
  );
}
