// Central place for constants; no magic numbers in components.
export const APP = { name: 'BalanceBoard', defaultLang: 'kk' as const, langStorageKey: 'bb.lang' };
export const LANGS = ['kk', 'ru', 'en'] as const;
export type Lang = (typeof LANGS)[number];
