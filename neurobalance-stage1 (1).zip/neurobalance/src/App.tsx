import { useState } from 'react';
import { Sidebar, type Route } from './ui/components/Sidebar';
import { Home } from './ui/screens/Home';
import { Stub, Settings } from './ui/screens/Stub';

export default function App() {
  const [route, setRoute] = useState<Route>('home');
  return (
    <div className="flex min-h-screen bg-sky text-ink">
      <Sidebar route={route} go={setRoute} />
      <main className="flex-1 overflow-auto p-6">
        {route === 'home' && <Home go={setRoute} />}
        {route === 'games' && <Stub title="nav_games" />}
        {route === 'results' && <Stub title="nav_results" />}
        {route === 'profile' && <Stub title="nav_profile" />}
        {route === 'journal' && <Stub title="nav_journal" />}
        {route === 'settings' && <Settings />}
      </main>
    </div>
  );
}
