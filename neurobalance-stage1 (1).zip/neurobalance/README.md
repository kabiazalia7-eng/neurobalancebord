# BalanceBoard (NeuroBalance) — исследовательский прототип

Не медицинское изделие. Приложение не содержит утверждений о лечении, диагностике или клинической эффективности.

## Состав
- `firmware/BalanceBoard/BalanceBoard.ino` — прошивка ESP32 + MPU6050 (открывается в **Arduino IDE**).
- `src/` — клиентское приложение (React + TypeScript + Vite + Tailwind, PWA).

## Прошивка (Arduino IDE)
1. Boards Manager → установить «esp32 by Espressif Systems».
2. Выбрать вашу плату ESP32 и порт, открыть `BalanceBoard.ino`, загрузить.
3. Подключение по умолчанию: MPU6050 SDA→GPIO21, SCL→GPIO22, VCC→3V3, GND→GND.
4. Прошивка отдаёт IMU-характеристику (12 байт, 100 Гц), Battery Service (0x180F) и Device Information (0x2A26, версия прошивки). Пин батареи — `BATTERY_PIN` (по умолчанию не подключён, отдаётся 100).

## Приложение
```
npm install
npm run dev      # http://localhost:5173
npm test
```
Web Bluetooth работает в Chrome/Edge на ПК и Android и требует secure context (localhost или HTTPS). На iOS — только демо-режим.
При подключении запрашивать `optionalServices`: `battery_service`, `device_information`.

## Архитектура (слои)
`ble → dsp → score → games → ui`, хранение в `db`, правила маскота и опциональный LLM в `assistant`, симулятор датчика в `sim`.

## Статус
Этап 1 готов: каркас, i18n (kk/ru/en), экраны-заглушки, дизайн-токены. Остальные этапы — по ТЗ.
