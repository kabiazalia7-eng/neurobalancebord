// BalanceBoard-01 firmware: ESP32 + MPU6050 -> BLE notify (12-byte packet, little-endian, 6 x int16)
// Arduino IDE: install "esp32 by Espressif Systems" in Boards Manager, pick your ESP32 board.
// Wiring (default): MPU6050 SDA -> GPIO21, SCL -> GPIO22, VCC -> 3V3, GND -> GND.
#include <Wire.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <esp_gap_ble_api.h>

// ---- Config (no magic numbers below) ----
static const char*  DEVICE_NAME   = "BalanceBoard-01";
static const char*  FW_VERSION    = "0.1.0";
#define SERVICE_UUID  "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define IMU_CHAR_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"
static const uint8_t  MPU_ADDR        = 0x68;
static const uint32_t SEND_PERIOD_US  = 10000;   // 100 Hz (spec: >= 50 Hz)
static const float    ACC_LSB_PER_G   = 16384.0; // +-2 g
static const float    GYR_LSB_PER_DPS = 131.0;   // +-250 deg/s
static const int      BATTERY_PIN     = -1;      // set ADC pin if you wire a voltage divider; -1 = report 100
static const uint32_t BATTERY_PERIOD_MS = 30000;
// BLE connection interval in 1.25 ms units: 6 = 7.5 ms, 12 = 15 ms (lower latency)
static const uint16_t CONN_INT_MIN = 6, CONN_INT_MAX = 12;

BLECharacteristic *imuChar, *battChar;
volatile bool connected = false;

class Callbacks : public BLEServerCallbacks {
  void onConnect(BLEServer*, esp_ble_gatts_cb_param_t* p) override {
    connected = true;
    esp_ble_conn_update_params_t cp = {};
    memcpy(cp.bda, p->connect.remote_bda, sizeof(esp_bd_addr_t));
    cp.min_int = CONN_INT_MIN; cp.max_int = CONN_INT_MAX; cp.latency = 0; cp.timeout = 400;
    esp_ble_gap_update_conn_params(&cp);
  }
  void onDisconnect(BLEServer*) override { connected = false; BLEDevice::startAdvertising(); }
};

static void mpuWrite(uint8_t reg, uint8_t val) { Wire.beginTransmission(MPU_ADDR); Wire.write(reg); Wire.write(val); Wire.endTransmission(); }

static bool readImu(int16_t out[6]) {
  Wire.beginTransmission(MPU_ADDR); Wire.write(0x3B); if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom((int)MPU_ADDR, 14) != 14) return false;
  int16_t raw[7];
  for (int i = 0; i < 7; i++) { uint8_t h = Wire.read(), l = Wire.read(); raw[i] = (int16_t)((h << 8) | l); }
  // raw: ax ay az temp gx gy gz -> g*1000 and deg/s*100
  for (int i = 0; i < 3; i++) out[i]     = (int16_t)(raw[i] / ACC_LSB_PER_G * 1000.0f);
  for (int i = 0; i < 3; i++) out[3 + i] = (int16_t)(raw[4 + i] / GYR_LSB_PER_DPS * 100.0f);
  return true;
}

static uint8_t readBattery() {
  if (BATTERY_PIN < 0) return 100;
  // Placeholder mapping: adjust to your divider and cell. 12-bit ADC, 3.3 V ref, 2:1 divider assumed.
  float v = analogRead(BATTERY_PIN) / 4095.0f * 3.3f * 2.0f;
  int pct = (int)((v - 3.3f) / (4.2f - 3.3f) * 100.0f);
  return (uint8_t)constrain(pct, 0, 100);
}

void setup() {
  Wire.begin(); Wire.setClock(400000);
  mpuWrite(0x6B, 0x00);  // wake up
  mpuWrite(0x1C, 0x00);  // accel +-2 g
  mpuWrite(0x1B, 0x00);  // gyro +-250 deg/s
  mpuWrite(0x1A, 0x03);  // DLPF ~44 Hz

  BLEDevice::init(DEVICE_NAME);
  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new Callbacks());

  BLEService* svc = server->createService(SERVICE_UUID);
  imuChar = svc->createCharacteristic(IMU_CHAR_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  imuChar->addDescriptor(new BLE2902());
  svc->start();

  BLEService* bat = server->createService(BLEUUID((uint16_t)0x180F));      // Battery Service
  battChar = bat->createCharacteristic(BLEUUID((uint16_t)0x2A19), BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  battChar->addDescriptor(new BLE2902());
  bat->start();

  BLEService* dis = server->createService(BLEUUID((uint16_t)0x180A));      // Device Information
  dis->createCharacteristic(BLEUUID((uint16_t)0x2A26), BLECharacteristic::PROPERTY_READ)->setValue(FW_VERSION);
  dis->start();

  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SERVICE_UUID);
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
}

void loop() {
  static uint32_t lastSend = 0, lastBatt = 0;
  uint32_t now = micros();
  if (connected && (uint32_t)(now - lastSend) >= SEND_PERIOD_US) {
    lastSend += SEND_PERIOD_US;
    if ((uint32_t)(now - lastSend) > 5 * SEND_PERIOD_US) lastSend = now;  // resync after a stall
    int16_t v[6];
    if (readImu(v)) {
      uint8_t pkt[12];
      memcpy(pkt, v, 12);  // ESP32 is little-endian: matches protocol
      imuChar->setValue(pkt, 12);
      imuChar->notify();
    }
  }
  if (connected && millis() - lastBatt >= BATTERY_PERIOD_MS) {
    lastBatt = millis();
    uint8_t b = readBattery(); battChar->setValue(&b, 1); battChar->notify();
  }
}
