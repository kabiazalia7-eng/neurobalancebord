/** Design tokens: dark-blue sidebar, light cards with large radii, blue/mint gradients. */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: {
    colors: { navy: '#12224a', navy2: '#1c2f63', sky: '#eef4ff', brand: '#3b82f6', mint: '#4fd8b8', ink: '#0f1b3d' },
    borderRadius: { card: '28px', pill: '999px' },
    fontFamily: { sans: ['ui-rounded', '"Nunito"', '"Segoe UI"', 'system-ui', 'sans-serif'] },
    backgroundImage: { 'grad-main': 'linear-gradient(135deg,#3b82f6,#4fd8b8)' }
  } },
  plugins: []
};
